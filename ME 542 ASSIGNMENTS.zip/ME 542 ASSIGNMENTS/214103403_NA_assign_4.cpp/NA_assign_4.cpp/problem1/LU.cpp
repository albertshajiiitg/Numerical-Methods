/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    int n=50,p;
    double A[n][n],L[n][n],U[n][n],x[n][n],y[n][n],b[n][n],c,s;
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            if(i+j<n){
               b[i][j]=(double)(i+j+1);
            }
            else{
                b[i][j]=(double)(i+j+1-n);
            }
        }
    }

    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            if(i==j){
                A[i][j]=5;
            }
            else if(fabs(i-j)==1){
                A[i][j]=-1;
            }
            else{
                A[i][j]=0;
            }
        }
    }
    for(int i=0;i<n-1;i++){
        c=A[i+1][i]/A[i][i];
        A[i+1][i]=c;
        A[i+1][i+1]=A[i+1][i+1]-c*A[i][i+1];
        
    }
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            if(i>j){
                L[i][j]=A[i][j];
            }
            else if(i==j){
                U[i][j]=A[i][j];
                L[i][j]=1;
            }
            else{
                U[i][j]=A[i][j];
            }
        }
    }
    for(int k=0;k<n;k++){
        for(int i=0;i<n;i++){

            if(i==0){
               y[i][k]=b[i][k];
                
            }
            else{
                s=0;
                for(int j=0;j<i;j++){
                    s=s+L[i][j]*y[j][k];
                
                }
                y[i][k]=b[i][k]-s;
            }
        }
    }
    for(int k=0;k<n;k++){
       for(int i=n-1;i>=0;i--){
            if(i==n-1){
               x[i][k]=y[i][k]/U[i][i];
            }
            else{
               s=0;
               for(int j=n-1;j>i;j--){
                   s=s+U[i][j]*x[j][k];
                }
                x[i][k]=(y[i][k]-s)/U[i][i];
            }
       }
    }
    cout<<"enter first entry of b vector:"<<endl;
    cin>>p;
    cout<<"solution for the above vector is :"<<endl;
    for(int i=0;i<n;i++){
        cout<<x[i][p-1]<<endl;
    }

    return 0;
}

