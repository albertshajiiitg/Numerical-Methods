#include<bits/stdc++.h>
using namespace std;

int main()
{
    ifstream file1;
    ifstream file2;
    ofstream file3;
    file1.open("newdata.txt");
    file2.open("newb.txt");
    file3.open("output.txt");
    int n=100,itrs=1000;
    double s;
    double **A = new double*[n];
    double *b =new double[n];
    vector<double>x;
    for(int i=0;i<n;i++){
        A[i] = new double[n];
    }
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            file1>>A[i][j];
        }
    }
    for(int i=0;i<n;i++){
        file2>>b[i];
    }
    for(int i=0;i<n;i++){
        x.push_back((double) rand()/RAND_MAX);
    }
    while(itrs>0){

        for(int i=0;i<n;i++){
           s=0;
           for(int j=0;j<n;j++){
               if(j==i){
                  continue;
               }
               else{
                  s=s+A[i][j]*x[j];
               }
           }
           x[i]=(b[i]-s)/A[i][i];
        }
        itrs--;
    }
    for(int i=0;i<n;i++){
        file3<<x[i]<<endl;
        }
    for(int i = 0; i <n; ++i){
        delete [] A[i];
    }
    delete [] A;
    delete [] b;
    file1.close();
    file2.close();
    file3.close();
    return 0;
}
