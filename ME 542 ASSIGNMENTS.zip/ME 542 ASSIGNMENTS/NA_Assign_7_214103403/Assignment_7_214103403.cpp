/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
#include <fstream>
using namespace std;

double f(double x,double y){
     return -2*x*x*x + 12*x*x - 20*x + 8.5;
}

double g(double x, double y){
    return -(x*x*x*x)*0.5 + 4*x*x*x - 10*x*x + 8.5*x +1;
}
int main()
{
    ofstream file1,file2,file3;
    file1.open("output1.txt");
    file2.open("output2.txt");
    file3.open("output3.txt");
    int i, time_steps=3;
    double x,y,y1,xn=4,k1,k2,k3,k4,n;
    double h[time_steps]={0.5,0.25,0.1};
    for(i=0;i<time_steps;i++){
        x=0;
        y=1;
        y1=1;
        n=(xn-x)/h[i];
        file1<<"solutions obtained using eulers method with time step "<<h[i]<<endl;
        file2<<"solutions obtained using RK4 method with time step "<<h[i]<<endl;
        file1<<"x       "<<"y "<<endl;
        file2<<"x       "<<"y "<<endl;
        for(int j=0;j<=n;j++){
            file1<<x<<"       "<<y<<" "<<endl;
            file2<<x<<"       "<<y1<<" "<<endl;
            y=y+f(x,y)*h[i];
            k1=f(x,y1);
            k2=f(x+h[i]/2,y1+k1*h[i]/2);
            k3=f(x+h[i]/2,y1+k2*h[i]/2);
            k4=f(x+h[i],y1+k3*h[i]);
            y1=y1+h[i]*(k1+2*(k2+k3)+k4)/6;
            x=x+h[i];
        }
    }
    i=i-1;
    file3<<"analytical solutions for time step : "<<h[i]<<endl;
    file3<<"x       "<<"y "<<endl;
    x=0;
    y=1;
    file3<<x<<"       "<<y<<" "<<endl;
    for(int j=0;j<n;j++){
        x=x+h[i];
        y= g(x,y);
        file3<<x<<"       "<<y<<" "<<endl;
    }
    file1.close();
    file2.close();
    file3.close();
    return 0;
}
