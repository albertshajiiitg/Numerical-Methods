#include <iostream>
#include <math.h>
#include <vector>
#include <fstream>
using namespace std;

double ci(double t,double h){
      return 1-cos(t)*h/2;
}

double di(double t, double h){
      return -2 -h*h*sin(t);
}

double ai(double t, double h){
      return 1+cos(t)*h/2;
}

double bi(double t, double h){
    return -h*h*exp(t);
}
int main()
{
    ofstream file;
    file.open("output.txt");
    int size =3;
    int n[size]={10,100,1000};
    double x0=0,xn=1,y0=0,yn=1,c,s;
    for(int k=0;k<size;k++){
    vector<vector<double>>A(n[k]-1, vector<double> (n[k]-1));
    vector<vector<double>>L(n[k]-1, vector<double> (n[k]-1));;
    vector<vector<double>>U(n[k]-1, vector<double> (n[k]-1));;
    vector<double>b(n[k]-1);
    vector<double>y(n[k]-1);
    vector<double>y1(n[k]-1);
    double h =(xn-x0)/double(n[k]);
    for(int i=0;i<n[k]-1;i++){
        for(int j=0;j<n[k]-1;j++){
            if(i==j){
               A[i][j]=di(x0+(i+1)*h,h);
            }
            else if(i-j==1){
               A[i][j]=ai(x0+(i+1)*h,h);
            }
            else if(j-i==1){
                A[i][j]=ci(x0+(i+1)*h,h);
            }
            else{
               A[i][j]=0;
            }
        }
    }
    for(int i=0;i<n[k]-1;i++){
        if(i==0){
           b[i]=bi(x0+(i+1)*h,h)-ai(x0+h,h)*y0;
           }
        else if(i==n[k]-2){
           b[i]=bi(x0+(i+1)*h,h)-ci(x0+(i+1)*h,h)*yn;
           }
        else{
           b[i]=bi(x0+(i+1)*h,h);
        }
    }


    for(int i=0;i<n[k]-2;i++){
        c=A[i+1][i]/A[i][i];
        A[i+1][i]=c;
        A[i+1][i+1]=A[i+1][i+1]-c*A[i][i+1];

    }
    for(int i=0;i<n[k]-1;i++){
        for(int j=0;j<n[k]-1;j++){
            if(i>j){
                L[i][j]=A[i][j];
            }
            else if(i==j){
                U[i][j]=A[i][j];
                L[i][j]=1;
            }
            else{
                U[i][j]=A[i][j];
            }
        }
    }


        for(int i=0;i<n[k]-1;i++){

            if(i==0){
               y1[i]=b[i];

            }
            else{
                s=0;
                for(int j=0;j<i;j++){
                    s=s+L[i][j]*y1[j];

                }
                y1[i]=b[i]-s;
            }
        }

       for(int i=n[k]-2;i>=0;i--){
            if(i==n[k]-2){
               y[i]=y1[i]/U[i][i];
            }
            else{
               s=0;
               for(int j=n[k]-2;j>i;j--){
                   s=s+U[i][j]*y[j];
                }
                y[i]=(y1[i]-s)/U[i][i];
            }
       }
       file<<" Output values at n = "<<n[k]<<" is :"<<endl;

       for(int i=0; i<n[k]-1;i++){
           file<<y[i]<<endl;
       }
    }
    
/*    for(int i=0;i<n-1;i++){
        for(int j=0;j<n-1;j++){
            cout<<A[i][j]<<"   ";
        }
        cout<<endl;
    }*/
    return 0;
}


