/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;


void max_arr(double arr[],int size,double *max,int *idx){        // function calculating value with max magnitude from an array
    *max =0;
    for(int i=0;i<size;i++){
        if(fabs(arr[i])>*max){
           *max=arr[i];
           *idx=i;
        }
        else{
             continue;
        }
    }
    
 }

int main()
{
    int n=4,itrs=1,max_itrs=10000,max_idx,max_err_idx;
    double q,s,mu,max_val,max_err_val,num =0,denom=0,TOL=0.000001;
    double A[n][n];double x1[n];double x[n];double y[n];double e[n];double Ax[n];
    ifstream file;
    file.open("A_matrix.txt");
    for(int i=0;i<n;i++){            // Reading from a file values of A matrix
        for(int j=0;j<n;j++){
            file>>A[i][j];
        }
    }
    for(int i=0;i<n;i++){          
        x[i]=rand();
        
    }
    /*for(int i=0;i<n;i++){
        s=0;
        for(int j=0;j<n;j++){
            s=s+A[i][j]*x[j];
        }
        Ax[i]=s;
    }
    for(int i=0;i<n;i++){
        num=num+x[i]*Ax[i];
        denom=denom +x[i]*x[i];
    }
    q=num/denom;*/
    cout<<"enter the value of shift:"<<endl;
    cin>>q;

    for(int i=0;i<n;i++){
        A[i][i]=A[i][i] - q;
    }
    max_arr(x,n,&max_val,&max_idx);
    for(int i=0;i<n;i++){
        x[i]=x[i]/max_val;
    }
    do{
        for(int i=0;i<n;i++){
            x1[i]=x[i];
        }
        for(int k=0;k<n-1;k++){
            for(int i=k+1;i<n;i++){
                for(int j=k+1;j<n;j++){
                    if(itrs==1){
                       A[i][j]=A[i][j] - (A[k][j]/A[k][k])*A[i][k];
                    }
                    else{
                        break;
                    }
                }
                x[i]=x[i]-(A[i][k]/A[k][k])*x[k];
            }
        }
        y[n-1]=x[n-1]/A[n-1][n-1];
        for(int k=n-2;k>=0;k--){
            s=0;
            for(int j=k+1;j<n;j++){
                s=s+A[k][j]*y[j];
            }
            y[k]=(x[k]-s)/A[k][k];
        }
        mu = y[max_idx];
        max_arr(y,n,&max_val,&max_idx);
    
        for(int i=0;i<n;i++){
            x[i]=y[i]/max_val;
            e[i]=fabs(x[i]-x1[i]);
        }
        itrs=itrs+1;
        max_arr(e,n,&max_err_val,&max_err_idx);
    }while(max_err_val>TOL&&itrs<max_itrs);
    cout<<"eigen value obtained for the selected shift is :"<<q+1/mu;
    file.close();
    return 0;
}
    
    
    

