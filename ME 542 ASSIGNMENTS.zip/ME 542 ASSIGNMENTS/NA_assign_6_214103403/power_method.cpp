/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;


double max_arr(double arr[],int size){        // function calculating value with max magnitude from an array
    double max =0;
    for(int i=0;i<size;i++){
        if(fabs(arr[i])>max){
           max=fabs(arr[i]);
        }
        else{
             continue;
        }
    }
    return max;
 }
int main()
{
    int n=4,itrs=1,max_itrs=500;
    double TOL=0.000001;
    double A[n][n];double x1[n];double x2[n]; double max_val; double e[n];
    ifstream file;
    file.open("A_matrix.txt");
    for(int i=0;i<n;i++){            // Reading from a file values of A matrix
        for(int j=0;j<n;j++){
            file>>A[i][j];
        }
    }

    for(int i=0;i<n;i++){           // initialize the eigen vector with random values
        x1[i]=rand();
    }
    max_val=max_arr(x1,n);
    for(int i=0;i<n;i++){
        x1[i]=x1[i]/max_val;
    }
    while(itrs<max_itrs){
         for(int i=0;i<n;i++){
            double s=0;
            for(int j=0;j<n;j++){
                s=s+A[i][j]*x1[j];
            }
            x2[i]=s;
         }
         max_val=max_arr(x2,n);
         if(max_val==0){
           cout<<"A has zero eigen value start with new guess"<<endl;
           break;
         }
         for(int i=0;i<n;i++){
             e[i]=x1[i]-x2[i]/max_val;
             x1[i]=x2[i]/max_val;
             }
         
         itrs=itrs+1;
     }
     if(max_arr(e,n)>TOL){
       cout<<"iterations limit exceeded.No solutions found"<<endl;
       }
     else{
        cout<<"eigen value is : "<<max_val<<endl;
        cout<<"eigen vector is :"<<endl;
        for(int i=0;i<n;i++){
           cout<< x1[i]<<endl;
           }
         }

    return 0;
}
