#include <iostream>
#include <cmath>
#include <fstream>
using namespace std;

double f(double z){
    return z;
}
double g(double x, double y,double z){
    return (32+ 2*x*x*x-y*z)/8;
}
double d_psy_func(double d_psy){
    return d_psy;
    }
double dd_psy_func(double y, double z, double psy,double d_psy){
    return -(z*psy +y*d_psy)/8;
}

double f_exact(double x){
    return x*x + 16/x;
}
int main()
{
    ofstream file,file1;
    file.open("output.txt");
     double x0= 1,xn=3,y0=17,yn=14.33333,z,x,y,x_exact,h,m=20,psy,d_psy,k1,k2,k3,k4,l1,l2,l3,l4,TOL=0.00001;
     int n=20;
     h=(xn-x0)/double(n);
     double Y[n+1];
     Y[0]=y0;

    do{
        z=m;
        x=x0;
        y=y0;
        psy=0;
        d_psy=1;
        for(int i =1;i<=n;i++){
         
        
         k1=f(z);
         l1=g(x,y,z);
         k2=f(z+l1*h/2);
         l2=g(x+h/2,y+k1*h/2,z+l1*h/2);
         k3=f(z+l2*h/2);
         l3=g(x+h/2,y+k2*h/2,z+l2*h/2);
         k4=f(z+l3*h);
         l4=g(x+h,y+k3*h,z+l3*h);
         y=y+(k1+2*(k2+k3)+k4)*h/6;
         z=z+(l1+2*(l2+l3)+l4)*h/6;
         k1=d_psy_func(d_psy);
         l1=dd_psy_func(y,z,psy,d_psy);
         k2=d_psy_func(d_psy+l1*h/2);
         l2=dd_psy_func(y,z,psy+k1*h/2,d_psy+l1*h/2);
         k3=d_psy_func(d_psy+l2*h/2);
         l3=dd_psy_func(y,z,psy+k2*h/2,d_psy+l2*h/2);
         k4=d_psy_func(d_psy+l3*h);
         l4=dd_psy_func(y,z,psy+k3*h,d_psy+l3*h);
         psy=psy+(k1+ 2*(k2+k3)+k4)*h/6;
         d_psy=d_psy+(l1+ 2*(l2+l3)+l4)*h/6;
    
         x=x+h;
        
         Y[i]=y;
        
         }
         m=m-(y-yn)/psy;


    }while(fabs(y-yn)>TOL);
    x_exact=x0;
    // printing values obtained using shooting method  and exact value in output.txt
    file<<"y        "<<"          exact_y"<<endl;
    for(int i=0;i<=n;i++)
    {
        file<<Y[i]<<"              "<<f_exact(x_exact)<<endl;
        x_exact=x_exact+h;
    }
    file.close();
    
    return 0;
    }

