#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;

double error(double arr1[] , double arr2[],int size){
    double result=0;
    for(int i=0;i<size; i++){
        result =result+(arr1[i]-arr2[i])*(arr1[i]-arr2[i]);
    }
    return sqrt(result);
}

int main()
{
   int  n=5,itrs=0,max_itrs=500;
   double TOL=0.000001;
   double A[n][n];double b[n];double x0[n];double x[n];
   ifstream file1;
   ifstream file2;
   file1.open("A_matrix.txt");
   file2.open("b_vector.txt");
   for(int i=0; i<n;i++){
       for(int j=0;j<n;j++){
           file1>>A[i][j];
       }
   }
   for(int i=0;i<n;i++){
       file2>>b[i];
   }

   for(int i=0;i<n;i++){
        x[i]=(double)rand();
    
    }
    do{
       for(int i =0;i<n;i++){
           x0[i]=x[i];
       }
       for(int i=0;i<n;i++){
           double s=0;
           for(int j=0;j<n;j++){
               if(i==j){
                   continue;
               }
               else{
                   s=s+A[i][j]*x[j];
               }
           }
           x[i]=(b[i]-s)/A[i][i];
       }
       itrs=itrs+1;
    }while(error(x,x0,n)>TOL&&itrs<max_itrs);
    if(error(x,x0,n)>TOL){
        cout<<"iteration limit excedeed"<<endl;
    }
    else{
        cout<<"solution of above system of equation using gauss siedel method :"<<endl;
        for(int i=0;i<n;i++){
           cout<<x[i]<<endl;
        }
        cout<<"number of iterations required:"<<endl;
        cout<<itrs;
    }

   file1.close();
   file2.close();

   return 0;
   }
