#include <iostream>
#include <cmath>
#include <vector>
#include <fstream>
using namespace std;

double f(double x){
    return x*exp(x)-1;
}

int main()
{
    double x,x1,x2,y,y1,y2,TOL=0.000001;
    vector<double>arr_x;
    int N=0, N_max=100;
    ofstream file("error_data1.txt");
    cout<<"enter intial guesses: "<<endl;
    cin>>x1>>x2;
    arr_x.push_back(x2);
    file<<"itr number"<<"    "<<"error"<<endl;
    do{
        y1=f(x1);
        y2=f(x2);
        x=x2-y2*(x2-x1)/(y2-y1);       
        x1=x2;
        x2=x;
        N=N+1;
        arr_x.push_back(x);
    }while(fabs(x1-x2)>TOL&&N<N_max);
    if(fabs(x1-x2)>TOL){
        cout<<"iteration limit exceeded"<<endl;
    }
    else{
        cout<<"zero of the given function is : "<<x<<endl;
    }
    for(int i=0;i<N;i++){
        file<<i<<"                    "<<fabs(x-arr_x[i])<<endl;
    }
    file.close();
    return 0;
}

