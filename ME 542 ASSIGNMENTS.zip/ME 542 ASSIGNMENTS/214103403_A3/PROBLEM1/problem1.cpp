#include <iostream>
#include <cmath>

using namespace std;

double f(double x){
    return x*x -x-2;
}
// finding zero using false position method for above function

int main()
{
    double a, b,zero,TOL=0.000001,N=0,N_max=1000;
    cout<<"enter lower limt of guess:"<<endl;
    cin>>a;
    cout<<"enter higher limit of the guess:"<<endl;
    cin>>b;
    if(f(a)*f(b)>0){
        cout<<"enter proper guess limits"<<endl;
    }
    else{
        while(fabs(b-a)>TOL&&N<N_max){
            zero=(a*f(b)-b*f(a))/(f(b)-f(a));
            if(f(zero)==0){
                break;
            }
            else if(f(zero)*f(b)<0){
               a=zero;
            }
            else{
                b=zero;
            }
            N=N+1;
            
        }
        if(f(zero)<=TOL){
            cout<<"zero of the given function is : "<<zero<<endl;
        }
        else{
            cout<<"shorten the range of limits, max possible iterations are exceeded"<<endl;
        }
    }
    

    return 0;
}

