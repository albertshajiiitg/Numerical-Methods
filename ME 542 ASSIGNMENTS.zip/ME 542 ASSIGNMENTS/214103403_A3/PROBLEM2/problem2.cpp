#include <iostream>
#include <vector>
#include <cmath>
#include <fstream>
using namespace std;

double f(double x){
    return x*exp(x)-1;
}
double g(double x){
    return exp(x)*(x+1);
}

int main()
{
    double x0,x,u=0,TOL=0.000001;
    vector<double>arr_x;
    int N=0,N_max=100;
    ofstream file("error_data.txt");
    cout<<"enter initial guess: "<<endl;
    cin>>x0;
    x=x0;
    arr_x.push_back(x);
    file<<"itr number"<<"    "<<"error"<<endl;
    do{
        u=f(x)/g(x);
        x=x-u;
        N=N+1;
        arr_x.push_back(x);
    }while(fabs(u)>TOL&&N<N_max);
    if(fabs(u)>TOL){
        cout<<"exceeded iteration limit change the guess "<<endl;
    }
    else{
        cout<<"the zero of the given function is : "<<x<<endl;
    }
    for(int i=0;i<N;i++){
        file<<i<<"                    "<<fabs(x-arr_x[i])<<endl;
    }
    file.close();

    return 0;
}

