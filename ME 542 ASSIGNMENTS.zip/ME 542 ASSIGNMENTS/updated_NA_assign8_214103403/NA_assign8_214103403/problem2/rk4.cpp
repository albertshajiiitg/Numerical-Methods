#include <iostream>

using namespace std;

double f(double x,double y,double z){
    return z;
}
double g(double x, double y,double z){
    return -4*z +2*y + 2*x*x*x -10;
}
int main()
{
    double t= 0,tn=1,y=0,z=1,h=0.01,k1,k2,k3,k4,l1,l2,l3,l4;
    while(t<=tn){
         k1=f(t,y,z);
         l1=g(t,y,z);
         k2=f(t+h/2,y+k1*h/2,z+l1*h/2);
         l2=g(t+h/2,y+k1*h/2,z+l1*h/2);
         k3=f(t+h/2,y+k2*h/2,z+l2*h/2);
         l3=g(t+h/2,y+k2*h/2,z+l2*h/2);
         k4=f(t+h,y+k3*h,z+l3*h);
         l4=g(t+h,y+k3*h,z+l3*h);
         y=y+(k1+2*(k2+k3)+k4)*h/6;
         z=z+(l1+2*(l2+l3)+l4)*h/6;
         t=t+h;
         }
    cout<<"solution of initial value problem at t = "<<tn<<" is "<<y<<endl;
    return 0;
}
