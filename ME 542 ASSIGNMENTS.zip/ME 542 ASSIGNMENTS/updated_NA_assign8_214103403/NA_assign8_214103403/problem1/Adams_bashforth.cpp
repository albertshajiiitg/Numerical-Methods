/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <fstream>
using namespace std;

double f(double t, double y){
       return 2- 2*t + 4*t*t -4*t*t*t - 4*t*t*t*t;
    }

int main()
{
    ofstream file;
    file.open("output.txt");
    file<<" t   "<<"     y"<<endl;
    int i =0,n=3;
    double t[n],y[n],h=0.01,s,k1,k2,k3,k4;
    t[0]=0;
    y[0]=1;
    while(i<n){
       file<<t[i]<<"         "<<y[i]<<endl;
       k1=f(t[i],y[i]);
       k2=f(t[i]+h/2,y[i]+k1*h/2);
       k3=f(t[i]+h/2,y[i]+k2*h/2);
       k4=f(t[i]+h,y[i]+k3*h);
       y[i+1]=y[i]+h*(k1+2*(k2+k3)+k4)/6;
       t[i+1]=t[i]+h;
       i++;
    }
    while(t[n]<1){
        file<<t[n]<<"         "<<y[n]<<endl;
        s= y[n]+h*(55*f(t[n],y[n]) - 59*f(t[n-1],y[n-1]) + 37*f(t[n-2],y[n-2]) - 9*f(t[n-3],y[n-3]))/24;
        for(int j=0;j<n;j++){
            
            y[j]=y[j+1];
            t[j]=t[j+1];
        }
        y[n]=s;
        t[n]=t[n-1]+h;
        
    }
    file<<t[n]<<"         "<<y[n]<<endl;
    file.close();
    return 0;
}